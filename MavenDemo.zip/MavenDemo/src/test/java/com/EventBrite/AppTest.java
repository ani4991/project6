package com.EventBrite;

import org.junit.Assert;

public class AppTest {
	public void Sample() {
		LoginPageTest login = new LoginPageTest();
		String[] args = null;
		LoginPageTest.main(args);
	}
	
}
