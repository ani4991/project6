package com.EventBrite;

public class EventDatabaseTest {
	
	String title, day, month, city, state, address, time;
	
	public void getTitle() {
		
	}
	public void getTime() {
		
	}
	public void setTitle(String line) {
		
	}
	public void setMonth(String line) {
		
	}
	public void setDay(String line) {
		
	}
	public void setCity(String line) {
		
	}
	public void setTime(String line) {
		
	}
	public void setState(String line) {
		
	}
}
