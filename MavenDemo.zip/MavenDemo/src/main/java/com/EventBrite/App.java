package com.EventBrite;

public class App {
	public void Sample() {
		LoginPage login = new LoginPage();
		String[] args = null;
		LoginPage.main(args);
	}
	
}
